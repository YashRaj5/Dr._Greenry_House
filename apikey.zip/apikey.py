apikey_huggingface = "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"
apikey_openai = "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"
